/**
 * LESA Facebook Agent — orchestrator.
 *
 * One "cycle" = generate -> brand-safety check -> publish (or skip + log).
 * A node-cron schedule runs cycles 2-3x per week. Includes a retry on a single
 * regeneration if the first draft fails the safety filter, so a one-off bad
 * draft doesn't waste a posting slot.
 *
 * Exposes runCycle() so you can also trigger a post on demand from a SynthDesk
 * admin route, and start()/stop() for the schedule.
 */

import cron, { ScheduledTask } from "node-cron";
import { generatePost, nextTheme } from "./contentEngine";
import { checkBrandSafety } from "./brandSafety";
import { publishToPage } from "./graphClient";
import { getValidPageToken } from "./tokenManager";
import { loadState, saveState, AgentState } from "./state";

export interface CycleOutcome {
  status: "posted" | "skipped" | "disabled" | "error";
  detail: string;
  postId?: string;
  theme?: string;
  text?: string;
}

const MAX_DRAFT_ATTEMPTS = 2;

export async function runCycle(): Promise<CycleOutcome> {
  const state: AgentState = await loadState();

  if (!state.enabled) {
    return { status: "disabled", detail: "Agent kill-switch is OFF." };
  }

  const theme = nextTheme(state.postCount);

  let lastReasons: string[] = [];
  for (let attempt = 1; attempt <= MAX_DRAFT_ATTEMPTS; attempt++) {
    let draftText = "";
    try {
      const draft = await generatePost(theme);
      draftText = draft.text;
    } catch (err) {
      const detail = `Generation failed (attempt ${attempt}): ${String(err)}`;
      state.lastError = detail;
      await saveState(state);
      if (attempt === MAX_DRAFT_ATTEMPTS) return { status: "error", detail };
      continue;
    }

    const safety = checkBrandSafety(draftText);
    if (!safety.ok) {
      lastReasons = safety.reasons;
      // try one more generation before giving up the slot
      if (attempt < MAX_DRAFT_ATTEMPTS) continue;
      const detail = `Skipped — failed brand safety: ${safety.reasons.join(" | ")}`;
      state.lastError = detail;
      await saveState(state);
      return { status: "skipped", detail, theme, text: draftText };
    }

    // Passed safety — publish.
    try {
      const pageToken = await getValidPageToken();
      const result = await publishToPage(draftText, pageToken);

      state.postCount += 1;
      state.history.push({
        at: new Date().toISOString(),
        theme,
        postId: result.id,
        text: draftText,
      });
      state.lastError = undefined;
      await saveState(state);

      return {
        status: "posted",
        detail: `Posted (${theme}).`,
        postId: result.id,
        theme,
        text: draftText,
      };
    } catch (err) {
      const detail = `Publish failed: ${String(err)}`;
      state.lastError = detail;
      await saveState(state);
      return { status: "error", detail, theme, text: draftText };
    }
  }

  return { status: "skipped", detail: `Exhausted attempts. Last reasons: ${lastReasons.join(" | ")}` };
}

let task: ScheduledTask | null = null;

/**
 * Start the 2-3x/week schedule.
 * Default: Mon, Wed, Fri at 9:15am America/New_York.
 * Override with FB_AGENT_CRON (standard cron expression).
 */
export function start(): void {
  const expr = process.env.FB_AGENT_CRON ?? "15 9 * * 1,3,5";
  task = cron.schedule(
    expr,
    async () => {
      const outcome = await runCycle();
      // Route this into SynthDesk's logger in production.
      console.log(`[lesa-fb-agent] ${new Date().toISOString()} ->`, outcome.status, "-", outcome.detail);
    },
    { timezone: "America/New_York" }
  );
  console.log(`[lesa-fb-agent] scheduled: "${expr}" (America/New_York)`);
}

export function stop(): void {
  task?.stop();
  task = null;
  console.log("[lesa-fb-agent] schedule stopped");
}
