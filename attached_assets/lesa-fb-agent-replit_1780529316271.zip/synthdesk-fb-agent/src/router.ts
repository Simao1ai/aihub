/**
 * Express router to wire the agent into SynthDesk's admin surface.
 * Mount with: app.use("/agents/lesa-fb", lesaFbRouter);
 *
 * Protect these routes with your existing Better Auth middleware before
 * exposing them — they can publish to a live Facebook Page.
 */

import { Router } from "express";
import { runCycle, start, stop } from "./agent";
import { loadState, saveState } from "./state";
import { generatePost, nextTheme } from "./contentEngine";
import { checkBrandSafety } from "./brandSafety";
import { tokenHealth, getValidPageToken } from "./tokenManager";

export const lesaFbRouter = Router();

// Current status + recent history.
lesaFbRouter.get("/status", async (_req, res) => {
  const state = await loadState();
  res.json({
    enabled: state.enabled,
    postCount: state.postCount,
    lastError: state.lastError ?? null,
    recent: state.history.slice(-10).reverse(),
  });
});

// Toggle the kill-switch.
lesaFbRouter.post("/toggle", async (req, res) => {
  const state = await loadState();
  state.enabled = Boolean(req.body?.enabled ?? !state.enabled);
  await saveState(state);
  res.json({ enabled: state.enabled });
});

// Dry-run: generate + safety-check the NEXT post without publishing.
lesaFbRouter.post("/preview", async (_req, res) => {
  const state = await loadState();
  const theme = nextTheme(state.postCount);
  const draft = await generatePost(theme);
  const safety = checkBrandSafety(draft.text);
  res.json({ theme, text: draft.text, safety });
});

// Force a real cycle now (respects kill-switch + safety).
lesaFbRouter.post("/run-now", async (_req, res) => {
  const outcome = await runCycle();
  res.json(outcome);
});

// Start / stop the cron schedule.
lesaFbRouter.post("/schedule/start", (_req, res) => { start(); res.json({ ok: true }); });
lesaFbRouter.post("/schedule/stop", (_req, res) => { stop(); res.json({ ok: true }); });

// Token diagnostics — shows validity/expiry without exposing the token itself.
lesaFbRouter.get("/token-health", async (_req, res) => {
  try {
    res.json(await tokenHealth());
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Force the token manager to validate/refresh/derive now (does not post).
lesaFbRouter.post("/token-refresh", async (_req, res) => {
  try {
    await getValidPageToken();          // runs the full bootstrap/refresh/derive path
    res.json({ ok: true, health: await tokenHealth() });
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err) });
  }
});
