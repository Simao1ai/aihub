/**
 * Replit Scheduled Deployment entrypoint.
 *
 * This is the script Replit runs on a schedule. It does NOT keep a process
 * alive — it runs exactly ONE posting cycle and exits. Replit's native cron
 * handles the timing, so there's no node-cron, no sleeping-Repl problem, and
 * no idle compute cost.
 *
 * Configure the schedule in Replit's Scheduled Deployment UI (e.g. cron
 * "15 9 * * 1,3,5", timezone America/New_York), and set the run command to:
 *   tsx src/runOnce.ts
 *
 * Exit code 0 on any handled outcome (posted/skipped/disabled) so Replit
 * doesn't mark the run as failed for an intentional skip. Non-zero only on a
 * genuine crash so failures surface in the deployment logs.
 */

import { runCycle } from "./agent";

async function main() {
  const outcome = await runCycle();
  const stamp = new Date().toISOString();
  console.log(`[lesa-fb-agent] ${stamp} -> ${outcome.status}: ${outcome.detail}`);
  if (outcome.postId) console.log(`[lesa-fb-agent] postId=${outcome.postId}`);
  if (outcome.text) console.log(`[lesa-fb-agent] preview:\n${outcome.text}`);

  // posted | skipped | disabled | error are all "handled" — exit 0.
  // Only an unhandled throw below should yield a non-zero exit.
}

main().catch((err) => {
  console.error("[lesa-fb-agent] FATAL:", err);
  process.exit(1);
});
