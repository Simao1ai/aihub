/**
 * Postgres-backed state store — use this on Replit Scheduled Deployments,
 * where the filesystem may NOT persist between runs (each run can be a fresh
 * container). This keeps post-count, history, and the kill-switch durable.
 *
 * SynthDesk already runs Postgres via Drizzle, but to keep this module
 * dependency-light it uses the `pg` driver directly against a single table.
 * Point DATABASE_URL at your SynthDesk database (Replit injects this as a
 * Secret automatically when you attach a Postgres DB).
 *
 * To use this instead of the JSON store, change the import in agent.ts and
 * router.ts from "./state" to "./statePg".
 *
 * One-time table creation (runs automatically on first call):
 *   create table if not exists lesa_fb_agent_state ( ... )
 */

import { Pool } from "pg";
import type { AgentState, PostRecord } from "./state";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const DEFAULT_STATE: AgentState = { enabled: true, postCount: 0, history: [] };

let initialized = false;
async function ensureTable(): Promise<void> {
  if (initialized) return;
  await pool.query(`
    create table if not exists lesa_fb_agent_state (
      id        integer primary key default 1,
      enabled   boolean not null default true,
      post_count integer not null default 0,
      history   jsonb   not null default '[]'::jsonb,
      last_error text,
      tokens    jsonb,
      check (id = 1)
    );
  `);
  // Add the column if an older table predates token support.
  await pool.query(`alter table lesa_fb_agent_state add column if not exists tokens jsonb;`);
  await pool.query(`insert into lesa_fb_agent_state (id) values (1) on conflict (id) do nothing;`);
  initialized = true;
}

export async function loadState(): Promise<AgentState> {
  await ensureTable();
  const { rows } = await pool.query(
    `select enabled, post_count, history, last_error from lesa_fb_agent_state where id = 1;`
  );
  if (rows.length === 0) return { ...DEFAULT_STATE };
  const r = rows[0];
  return {
    enabled: r.enabled,
    postCount: r.post_count,
    history: (r.history as PostRecord[]) ?? [],
    lastError: r.last_error ?? undefined,
    tokens: (r.tokens as AgentState["tokens"]) ?? undefined,
  };
}

export async function saveState(state: AgentState): Promise<void> {
  await ensureTable();
  await pool.query(
    `update lesa_fb_agent_state
       set enabled = $1, post_count = $2, history = $3::jsonb, last_error = $4, tokens = $5::jsonb
     where id = 1;`,
    [
      state.enabled,
      state.postCount,
      JSON.stringify(state.history),
      state.lastError ?? null,
      state.tokens ? JSON.stringify(state.tokens) : null,
    ]
  );
}
