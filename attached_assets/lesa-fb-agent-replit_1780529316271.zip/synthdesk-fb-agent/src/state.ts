/**
 * Minimal persistent state for the agent. In SynthDesk you'd likely back this
 * with Postgres/Drizzle, but a JSON file keeps the module self-contained and
 * easy to drop in. Swap `load`/`save` for DB calls when integrating.
 */

import { promises as fs } from "fs";
import path from "path";

const STATE_PATH = process.env.FB_AGENT_STATE ?? path.join(process.cwd(), "fb-agent-state.json");

export interface PostRecord {
  at: string;        // ISO timestamp
  theme: string;
  postId: string;
  text: string;
}

/**
 * Stored OAuth credentials, persisted so tokens survive restarts and
 * scheduled runs. The long-lived USER token is the thing we refresh; the PAGE
 * token is re-derived from it. We track when the user token was last refreshed
 * so we can proactively renew it before the ~60-day expiry.
 */
export interface TokenRecord {
  longLivedUserToken: string;
  userTokenRefreshedAt: string;   // ISO timestamp of last successful refresh
  pageToken?: string;             // derived from the user token
  pageTokenDerivedAt?: string;    // ISO timestamp
}

export interface AgentState {
  enabled: boolean;          // kill-switch
  postCount: number;         // drives theme rotation
  history: PostRecord[];
  lastError?: string;
  tokens?: TokenRecord;      // managed by tokenManager.ts
}

const DEFAULT_STATE: AgentState = { enabled: true, postCount: 0, history: [] };

export async function loadState(): Promise<AgentState> {
  try {
    const raw = await fs.readFile(STATE_PATH, "utf8");
    return { ...DEFAULT_STATE, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULT_STATE };
  }
}

export async function saveState(state: AgentState): Promise<void> {
  await fs.writeFile(STATE_PATH, JSON.stringify(state, null, 2), "utf8");
}
