/**
 * Content engine — generates an on-brand Facebook post for LESA Inspections
 * using the Claude API, grounded entirely in the LESA knowledge base.
 *
 * Rotates through post "themes" so the feed doesn't get repetitive across
 * 2-3 posts/week. The current month's seasonal angles are injected so content
 * stays timely.
 */

import Anthropic from "@anthropic-ai/sdk";
import { LESA } from "./lesaKnowledge";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export type PostTheme =
  | "educational_tip"        // homeowner/buyer education
  | "service_spotlight"      // highlight one specialty service
  | "warranty_value"         // lead with the $100K warranties
  | "seasonal"               // tied to the month
  | "realtor_partner"        // speak to agent referral partners
  | "trust_credibility";     // certifications, years, satisfaction guarantee

const THEME_ROTATION: PostTheme[] = [
  "educational_tip",
  "seasonal",
  "service_spotlight",
  "warranty_value",
  "realtor_partner",
  "trust_credibility",
];

/** Pick the next theme based on how many posts have gone out (round-robin). */
export function nextTheme(postCount: number): PostTheme {
  return THEME_ROTATION[postCount % THEME_ROTATION.length];
}

function buildPrompt(theme: PostTheme): string {
  const month = new Date().getMonth() + 1;
  const seasonal = LESA.seasonalAngles[month] ?? [];

  return `You are the social media voice of ${LESA.name}, a New Jersey home inspection company.

Write ONE Facebook post. Output ONLY the post text — no preamble, no quotes, no markdown, no hashanalysis.

BUSINESS FACTS (use only these — do not invent anything):
- ${LESA.yearsInBusiness}+ years in business, serving ${LESA.serviceArea}.
- Certifications: ${LESA.certifications.join(", ")}.
- Core services: ${LESA.services.core.join(", ")}.
- Specialty services: ${LESA.services.specialty.join(", ")}.
- Key differentiators: ${LESA.advantages.slice(0, 5).join("; ")}.
- Warranties: ${LESA.warranties.slice(0, 3).join("; ")}.
- Phone: ${LESA.phone}. Website: ${LESA.website}. Schedule: ${LESA.scheduleUrl}.
- Tagline: "${LESA.tagline}".

BRAND VOICE:
${LESA.brandVoice.map((v) => `- ${v}`).join("\n")}

THIS POST'S THEME: ${theme}
${seasonal.length ? `TIMELY ANGLES FOR THIS MONTH: ${seasonal.join("; ")}.` : ""}

RULES:
- 2 to 4 short paragraphs OR a tight list. Keep it scannable.
- Educational and trustworthy first; soft call-to-action last.
- Include the phone (${LESA.phone}) OR website naturally — not both stuffed in.
- Use 2-4 relevant hashtags at the very end (e.g. #HomeInspection #NewJerseyRealEstate).
- NEVER overpromise (no "guaranteed pass", no "best in NJ", no "we guarantee your home").
- Use "we/our", never "I/my".
- Length between 80 and 1500 characters.`;
}

export interface GeneratedPost {
  theme: PostTheme;
  text: string;
}

export async function generatePost(theme: PostTheme): Promise<GeneratedPost> {
  const msg = await client.messages.create({
    model: "claude-opus-4-8",
    max_tokens: 1024,
    messages: [{ role: "user", content: buildPrompt(theme) }],
  });

  const text = msg.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .trim();

  return { theme, text };
}
