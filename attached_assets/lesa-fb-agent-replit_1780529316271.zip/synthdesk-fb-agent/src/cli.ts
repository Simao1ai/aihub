/**
 * CLI for local testing.
 *   npm run preview   -> generate + safety-check next post (no publish)
 *   npm run run-now   -> generate + check + publish one post
 *   npm run start     -> start the cron schedule and stay alive
 */

import { runCycle, start } from "./agent";
import { generatePost, nextTheme } from "./contentEngine";
import { checkBrandSafety } from "./brandSafety";
import { loadState } from "./state";

const cmd = process.argv[2];

async function main() {
  switch (cmd) {
    case "preview": {
      const state = await loadState();
      const theme = nextTheme(state.postCount);
      const draft = await generatePost(theme);
      const safety = checkBrandSafety(draft.text);
      console.log(`\n--- THEME: ${theme} ---\n`);
      console.log(draft.text);
      console.log(`\n--- SAFETY: ${safety.ok ? "PASS" : "FAIL"} ---`);
      if (!safety.ok) console.log(safety.reasons.join("\n"));
      break;
    }
    case "run-now": {
      const outcome = await runCycle();
      console.log(outcome);
      break;
    }
    case "start": {
      start();
      // keep process alive
      setInterval(() => {}, 1 << 30);
      break;
    }
    case "token-health": {
      const { tokenHealth } = await import("./tokenManager");
      console.log(await tokenHealth());
      break;
    }
    case "token-refresh": {
      const { getValidPageToken, tokenHealth } = await import("./tokenManager");
      await getValidPageToken();
      console.log("Refreshed. Health:", await tokenHealth());
      break;
    }
    default:
      console.log("Usage: cli.ts <preview|run-now|start|token-health|token-refresh>");
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
