/**
 * Automatic Facebook token management.
 *
 * The problem this solves: a Page access token derived from a long-lived user
 * token effectively does not expire — BUT the long-lived USER token it came
 * from expires in ~60 days. If that user token lapses, every future Page-token
 * derivation breaks and posting silently stops.
 *
 * Strategy:
 *   1. BOOTSTRAP: on first run, take FB_USER_TOKEN from the environment,
 *      exchange it for a long-lived user token, and persist it in state.
 *   2. REFRESH:  before the stored user token gets close to expiry, exchange
 *      it again for a fresh long-lived token (Facebook lets you re-exchange a
 *      still-valid long-lived token to extend it). Persist the new one.
 *   3. DERIVE:   (re)derive the Page token from the current user token and
 *      cache it. Page tokens don't expire while the user token is valid.
 *
 * Every posting cycle calls getValidPageToken(), which transparently handles
 * all of the above. You set FB_USER_TOKEN once; after that the agent maintains
 * itself. Re-seeding is only needed if the token is somehow fully revoked.
 */

import {
  getLongLivedUserToken,
  getPageToken,
  inspectToken,
} from "./graphClient";
import { loadState, saveState, AgentState, TokenRecord } from "./state";

// Refresh the user token when it's within this window of expiry, OR when we
// can't read an expiry and it's simply older than the soft age below.
const REFRESH_WHEN_WITHIN_DAYS = 10;     // proactive renewal margin
const SOFT_REFRESH_AGE_DAYS = 45;        // fallback if expiry is unreadable
const DAY_MS = 24 * 60 * 60 * 1000;

function daysSince(iso: string): number {
  return (Date.now() - new Date(iso).getTime()) / DAY_MS;
}

/**
 * Decide whether the stored long-lived user token should be refreshed now.
 * Prefers Facebook's real expiry (via debug_token); falls back to token age.
 */
async function userTokenNeedsRefresh(rec: TokenRecord): Promise<boolean> {
  try {
    const info = await inspectToken(rec.longLivedUserToken);
    if (!info.isValid) return true;
    if (info.expiresAt && info.expiresAt > 0) {
      const msUntilExpiry = info.expiresAt * 1000 - Date.now();
      return msUntilExpiry < REFRESH_WHEN_WITHIN_DAYS * DAY_MS;
    }
    // expiresAt 0/null => effectively non-expiring; no refresh needed.
    return false;
  } catch {
    // If inspection fails, fall back to age-based heuristic.
    return daysSince(rec.userTokenRefreshedAt) >= SOFT_REFRESH_AGE_DAYS;
  }
}

/** Bootstrap a TokenRecord from the FB_USER_TOKEN env secret. */
async function bootstrapFromEnv(): Promise<TokenRecord> {
  const seed = process.env.FB_USER_TOKEN;
  if (!seed) {
    throw new Error(
      "No stored tokens and FB_USER_TOKEN is not set. Seed FB_USER_TOKEN once (Graph Explorer user token) so the agent can self-manage from then on."
    );
  }
  const longLived = await getLongLivedUserToken(seed);
  const pageToken = await getPageToken(longLived);
  const now = new Date().toISOString();
  return {
    longLivedUserToken: longLived,
    userTokenRefreshedAt: now,
    pageToken,
    pageTokenDerivedAt: now,
  };
}

/**
 * Return a valid Page token, refreshing/deriving as needed and persisting any
 * changes. This is the single entrypoint the rest of the agent should use.
 */
export async function getValidPageToken(): Promise<string> {
  // An explicit cached Page token in env always wins (manual override path).
  if (process.env.FB_PAGE_TOKEN) return process.env.FB_PAGE_TOKEN;

  const state: AgentState = await loadState();
  let changed = false;

  // 1. Bootstrap if we have nothing stored yet.
  if (!state.tokens) {
    state.tokens = await bootstrapFromEnv();
    changed = true;
  }

  // 2. Refresh the user token if it's near expiry / invalid.
  if (await userTokenNeedsRefresh(state.tokens)) {
    try {
      const refreshed = await getLongLivedUserToken(state.tokens.longLivedUserToken);
      state.tokens.longLivedUserToken = refreshed;
      state.tokens.userTokenRefreshedAt = new Date().toISOString();
      // Force a Page-token re-derivation after a user-token change.
      state.tokens.pageToken = undefined;
      changed = true;
    } catch (err) {
      // Re-exchange failed (likely fully expired/revoked). Try env reseed.
      try {
        state.tokens = await bootstrapFromEnv();
        changed = true;
      } catch {
        throw new Error(
          `Token refresh failed and re-seed from FB_USER_TOKEN failed too: ${String(err)}. ` +
            `Re-mint FB_USER_TOKEN in Graph Explorer and update the Secret.`
        );
      }
    }
  }

  // 3. (Re)derive the Page token if missing.
  if (!state.tokens.pageToken) {
    state.tokens.pageToken = await getPageToken(state.tokens.longLivedUserToken);
    state.tokens.pageTokenDerivedAt = new Date().toISOString();
    changed = true;
  }

  if (changed) await saveState(state);
  return state.tokens.pageToken!;
}

/** Diagnostics for the admin UI: current token health without exposing secrets. */
export async function tokenHealth(): Promise<{
  hasStoredToken: boolean;
  userTokenRefreshedAt: string | null;
  userTokenValid: boolean | null;
  userTokenExpiresAt: number | null;
  pageTokenDerivedAt: string | null;
}> {
  const state = await loadState();
  if (!state.tokens) {
    return {
      hasStoredToken: false,
      userTokenRefreshedAt: null,
      userTokenValid: null,
      userTokenExpiresAt: null,
      pageTokenDerivedAt: null,
    };
  }
  let valid: boolean | null = null;
  let expiresAt: number | null = null;
  try {
    const info = await inspectToken(state.tokens.longLivedUserToken);
    valid = info.isValid;
    expiresAt = info.expiresAt;
  } catch {
    /* leave as null if inspection fails */
  }
  return {
    hasStoredToken: true,
    userTokenRefreshedAt: state.tokens.userTokenRefreshedAt,
    userTokenValid: valid,
    userTokenExpiresAt: expiresAt,
    pageTokenDerivedAt: state.tokens.pageTokenDerivedAt ?? null,
  };
}
