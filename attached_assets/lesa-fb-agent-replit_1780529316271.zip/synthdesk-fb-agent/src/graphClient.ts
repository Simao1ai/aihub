/**
 * Facebook Graph API client for LESA's Page.
 *
 * Handles the token reality of Facebook:
 *   short-lived user token  ->  long-lived user token (~60 days)
 *   long-lived user token   ->  Page access token (effectively non-expiring
 *                               while refreshed)
 *
 * Posting to a Page you own/admin works in the app's Development mode without
 * App Review. You only need pages_manage_posts via App Review to post to Pages
 * you do not own. Since LESA owns its Page, this runs today in dev mode.
 *
 * Required env:
 *   FB_APP_ID, FB_APP_SECRET
 *   FB_PAGE_ID
 *   FB_USER_TOKEN          (a long-lived user token, or short-lived to exchange)
 * Optional:
 *   FB_PAGE_TOKEN          (cached Page token; if absent we derive it)
 *   FB_GRAPH_VERSION       (default v21.0)
 */

const GRAPH = `https://graph.facebook.com/${process.env.FB_GRAPH_VERSION ?? "v21.0"}`;

async function graphGet(path: string, params: Record<string, string>): Promise<any> {
  const qs = new URLSearchParams(params).toString();
  const res = await fetch(`${GRAPH}/${path}?${qs}`);
  const json = await res.json();
  if (!res.ok || json.error) {
    throw new Error(`Graph GET ${path} failed: ${JSON.stringify(json.error ?? json)}`);
  }
  return json;
}

async function graphPost(path: string, body: Record<string, string>): Promise<any> {
  const res = await fetch(`${GRAPH}/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(body).toString(),
  });
  const json = await res.json();
  if (!res.ok || json.error) {
    throw new Error(`Graph POST ${path} failed: ${JSON.stringify(json.error ?? json)}`);
  }
  return json;
}

/** Exchange any user token for a long-lived (~60 day) user token. */
export async function getLongLivedUserToken(shortToken: string): Promise<string> {
  const json = await graphGet("oauth/access_token", {
    grant_type: "fb_exchange_token",
    client_id: process.env.FB_APP_ID!,
    client_secret: process.env.FB_APP_SECRET!,
    fb_exchange_token: shortToken,
  });
  return json.access_token as string;
}

/** Derive a Page access token from a long-lived user token. */
export async function getPageToken(longLivedUserToken: string): Promise<string> {
  const pageId = process.env.FB_PAGE_ID!;
  const json = await graphGet(`${pageId}`, {
    fields: "access_token",
    access_token: longLivedUserToken,
  });
  if (!json.access_token) {
    throw new Error("No Page access token returned — check that the user admins this Page.");
  }
  return json.access_token as string;
}

/** Resolve a usable Page token, exchanging/deriving as needed. */
export async function resolvePageToken(): Promise<string> {
  if (process.env.FB_PAGE_TOKEN) return process.env.FB_PAGE_TOKEN;
  const longLived = await getLongLivedUserToken(process.env.FB_USER_TOKEN!);
  return getPageToken(longLived);
}

export interface TokenInfo {
  isValid: boolean;
  expiresAt: number | null; // unix seconds; 0 or null means "never"/long-lived
  scopes: string[];
}

/**
 * Inspect a token via Graph's debug_token endpoint to read its real validity
 * and expiry straight from Facebook, instead of guessing from elapsed time.
 * Uses an app access token (app_id|app_secret) as the inspector.
 */
export async function inspectToken(inputToken: string): Promise<TokenInfo> {
  const appAccessToken = `${process.env.FB_APP_ID}|${process.env.FB_APP_SECRET}`;
  const json = await graphGet("debug_token", {
    input_token: inputToken,
    access_token: appAccessToken,
  });
  const d = json.data ?? {};
  return {
    isValid: Boolean(d.is_valid),
    // data_access_expires_at / expires_at = 0 means it doesn't expire.
    expiresAt: typeof d.expires_at === "number" ? d.expires_at : null,
    scopes: Array.isArray(d.scopes) ? d.scopes : [],
  };
}

export interface PublishResult {
  id: string;        // Facebook post id
  permalink?: string;
}

/** Publish a text post to the LESA Page. */
export async function publishToPage(message: string, pageToken: string): Promise<PublishResult> {
  const pageId = process.env.FB_PAGE_ID!;
  const json = await graphPost(`${pageId}/feed`, {
    message,
    access_token: pageToken,
  });
  return { id: json.id as string };
}
