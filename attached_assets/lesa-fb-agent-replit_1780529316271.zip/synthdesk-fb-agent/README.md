# LESA Facebook Agent (SynthDesk module)

A fully autonomous agent that generates on-brand Facebook posts for **LESA
Inspections** from the company knowledge base and publishes them to the LESA
Page **2–3× per week** (Mon/Wed/Fri 9:15am ET by default).

Every post must clear a **brand-safety filter** before it can go live, and a
**kill-switch** lets you pause posting instantly. "Autonomous" still means "can
never publish something off-brand."

## How it works (one cycle)

```
generate (Claude API, grounded in lesaKnowledge.ts)
   -> brand-safety check (brandSafety.ts)
        pass -> publish to Page (Graph API)  -> log to state
        fail -> regenerate once, else skip the slot + log reason
```

Themes rotate so the feed stays varied: educational tip → seasonal → service
spotlight → warranty value → realtor partner → trust/credibility → repeat.

## Files

| File | Purpose |
|---|---|
| `lesaKnowledge.ts` | Single source of truth for all LESA facts. Edit here. |
| `contentEngine.ts` | Builds the prompt + calls Claude to draft a post. |
| `brandSafety.ts` | Hard guardrail every post must pass. |
| `graphClient.ts` | Token exchange + publishing to the Page. |
| `state.ts` | Post count, history, kill-switch (JSON; swap for Drizzle). |
| `agent.ts` | Orchestrator + cron schedule. |
| `router.ts` | Express routes for the SynthDesk admin UI. |
| `cli.ts` | Local testing without the server. |

## Meta setup (the part that takes effort)

You own the LESA Page, so you can run this in the app's **Development mode
without App Review** — dev-mode apps can post to Pages you admin.

1. **Create an app** at developers.facebook.com → "Business" type. Grab the
   **App ID** and **App Secret** → `FB_APP_ID`, `FB_APP_SECRET`.
2. **Add the Facebook Login product** (needed to mint user tokens).
3. In **Graph API Explorer**: select your app, click *Generate Access Token*,
   and grant `pages_show_list`, `pages_read_engagement`, `pages_manage_posts`.
   Copy that user token → `FB_USER_TOKEN`.
4. **Get the Page ID**: in Graph Explorer call `me/accounts` — find LESA in the
   list, copy its `id` → `FB_PAGE_ID`.
5. The agent will automatically exchange the user token for a long-lived one and
   derive the Page token. (Optionally cache the Page token in `FB_PAGE_TOKEN`.)

> Token lifetimes are handled automatically. You seed `FB_USER_TOKEN` once; the
> agent exchanges it for a long-lived token, persists it, and auto-refreshes it
> before the ~60-day expiry — re-deriving the Page token as needed. See the
> token manager in `tokenManager.ts`. Check health via the `/token-health`
> route or `npx tsx src/cli.ts token-health`.

## Run it

```bash
cp .env.example .env   # fill in values
npm install
npm run preview        # see the next post WITHOUT publishing — do this first
npm run run-now        # generate + publish one real post
npm run start          # start the 2-3x/week schedule
```

**Always run `npm run preview` a few times first** to sanity-check the voice
before letting it post live.

## Wire into SynthDesk

```ts
import { lesaFbRouter } from "lesa-fb-agent/router";
import { start } from "lesa-fb-agent/agent";

app.use("/agents/lesa-fb", requireAuth, lesaFbRouter); // your Better Auth guard
start(); // begin the schedule on boot
```

Admin routes: `GET /status`, `POST /toggle`, `POST /preview`,
`POST /run-now`, `POST /schedule/start`, `POST /schedule/stop`.

## Recommended: keep a soft human gate at first

Even though this is built to run autonomously, for the first few weeks consider
setting the cron to a manual trigger and using `POST /preview` (or the CLI
`preview`) to eyeball posts before they publish. Once you trust the voice, flip
to the full schedule. One off-brand post can cost a realtor referral — the
guardrails reduce that risk but your eye is still the best filter early on.
