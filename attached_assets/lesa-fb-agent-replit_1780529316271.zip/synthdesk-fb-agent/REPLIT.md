# Running the LESA Facebook Agent on Replit

Two hosting models. Pick one based on whether this stands alone or rides inside
your already-running SynthDesk server.

---

## Decision: which model?

| | Scheduled Deployment | Reserved VM (always-on) |
|---|---|---|
| Best when | This is a **standalone** 2-3x/week poster | This lives **inside SynthDesk's** Express process |
| How timing works | Replit's **native cron** triggers `runOnce.ts` | `node-cron` inside a long-lived process |
| Sleeping-Repl risk | None — no persistent process | None — Reserved VMs don't sleep |
| Cost | Lower (no idle compute) | Pay for always-on |
| State store | **Use Postgres** (`statePg.ts`) | JSON file is fine (`state.ts`) |
| **Recommended for you** | ✅ if separate from SynthDesk | ✅ if bundled with SynthDesk |

Since you host SynthDesk on Replit already, the cleanest move is: if you want
this as its own thing, use a **Scheduled Deployment**; if you'd rather it be
"just another agent" in the SynthDesk server, mount the router and call
`start()` in that already-always-on process.

---

## Path A — Scheduled Deployment (standalone)

1. **Create the Repl** and upload this module (or import the GitHub repo).
2. **Secrets** (lock icon — NOT a .env file):
   - `ANTHROPIC_API_KEY`
   - `FB_APP_ID`, `FB_APP_SECRET`, `FB_PAGE_ID`, `FB_USER_TOKEN`
   - `DATABASE_URL` (attach a Replit Postgres DB — see step 3)
3. **Attach Postgres**: Tools → Database → create. Replit injects
   `DATABASE_URL` as a Secret automatically. This makes state durable across
   scheduled runs (the filesystem may not persist between them).
4. **Switch to the Postgres store**: in `src/agent.ts` and `src/router.ts`,
   change `from "./state"` to `from "./statePg"`. (The interface is identical.)
5. **Test before scheduling**: hit the green Run button — it does a safe
   `preview` (generate + safety-check, no publish). Run it a few times and read
   the drafts.
6. **Deploy → Scheduled**:
   - Build command: `npm install`
   - Run command: `npx tsx src/runOnce.ts`
   - Schedule: `15 9 * * 1,3,5`  (Mon/Wed/Fri 9:15am)
   - Timezone: `America/New_York`
7. Watch the first scheduled run in the Deployment logs. `runOnce.ts` prints the
   outcome and a preview of what it posted.

---

## Path B — Reserved VM (bundled in SynthDesk)

1. Add the files to your SynthDesk repo (e.g. `src/agents/lesa-fb/`).
2. Add the same Secrets as above to the SynthDesk Repl.
3. In your SynthDesk server bootstrap:
   ```ts
   import { lesaFbRouter } from "./agents/lesa-fb/router";
   import { start } from "./agents/lesa-fb/agent";

   app.use("/agents/lesa-fb", requireAuth, lesaFbRouter); // Better Auth guard
   start(); // node-cron begins; SynthDesk is already always-on
   ```
4. Keep the JSON state store, or switch to `statePg.ts` to share SynthDesk's DB.
5. Deploy SynthDesk as a **Reserved VM** so the process never sleeps.

---

## Replit gotchas (read these)

- **Secrets, not `.env`.** Replit injects Secrets as env vars. `process.env.X`
  works unchanged. Never commit secrets.
- **Sleeping Repls skip cron.** A normal (non-deployed) Repl sleeps with no
  traffic, and `node-cron` won't fire while asleep. That's exactly why a
  Scheduled Deployment (Path A) or Reserved VM (Path B) is required — don't try
  to run this from the editor and expect it to post on schedule.
- **State persistence.** On Scheduled Deployments use Postgres (`statePg.ts`) or
  theme rotation and history will reset. On a Reserved VM the JSON file persists.
- **Token expiry — now automatic.** You seed `FB_USER_TOKEN` **once**. On the
  first run the agent exchanges it for a long-lived user token, stores it
  (Postgres or JSON), and from then on **auto-refreshes** it before the ~60-day
  expiry and re-derives the Page token as needed. No calendar reminder required.
  Check status anytime via `GET /agents/lesa-fb/token-health` or the CLI
  `npx tsx src/cli.ts token-health`. You'd only re-seed `FB_USER_TOKEN` if the
  token is fully revoked (e.g. you change your FB password or pull the app's
  permissions).
- **tsx vs build.** The run commands use `npx tsx` to run TypeScript directly —
  no build step needed on Replit. If you prefer compiled JS, run `npm run build`
  and point the run command at `dist/runOnce.js`.
